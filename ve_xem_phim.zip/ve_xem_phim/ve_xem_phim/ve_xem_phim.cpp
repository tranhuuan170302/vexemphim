﻿
//
#include<queue>
#include <iostream>
#include<string.h>
using namespace std;
//danh sách liên kết đơn A
//khai báo node a
struct nodeA {
    int soghetrong;
    nodeA* pnext;
};
// khai báo 2 con trỏ để quản lí danh sách A
struct listA
{
    nodeA* phead;
    nodeA* ptail;
};
//=================khởi tạo node=================
void khoitaolistA(listA& l) {
    l.phead = NULL;
    l.ptail = NULL;
}

nodeA* khoitaonodeA(listA &l,int x) {
    nodeA* p = new nodeA;
    if (p == NULL) {
        cout << "bo nho day";
    }
    else {
        p->soghetrong = x;
        p->pnext = l.phead;
    }
    return p;
}
//thêm cuối vào 
void themvaocuoiA(listA& l, int x) {
    nodeA* data = new nodeA;
    data->soghetrong = x;
    data->pnext = NULL;
    if (l.phead == NULL) {
        l.phead = l.ptail = data;
    }
    else {
        l.ptail->pnext = data;
        l.ptail = data;
    }
}
//tính độ dài của nodeA
void ListLen(listA l) {
    int i = 0;
    for (nodeA* k = l.phead; k != NULL; k->pnext) {
        i++;
    }
    cout<< i;
}
//tìm phần tử
int position(listA l, int x) {
    
    for (nodeA* k = l.phead; k != NULL; k->pnext) {
        
        if (k->soghetrong == x) {
            return x;
        }
    }
    return -1;
}



void removeA_before(listA& l, int x) {
    nodeA* q = new nodeA;
    q->soghetrong = x;
    if (l.phead == NULL) {
        cout << "khon co du lieu de xoa";
    }
    else {
        nodeA *p = l.phead;
        l.phead = l.phead->pnext;//cập nhật lại l.phead là phần tử kế tiếp
        delete p;
    }
}
void removeA_after(listA& l, int x) {
    nodeA* q = new nodeA;
    q->soghetrong = x;
    if (l.phead == NULL) {
        cout << "khong co du lieu de xoa!!\n";
    }
    else {
        for (nodeA* k = l.phead; k != NULL; k->pnext) {
            if (k->pnext = l.ptail) {
                delete l.ptail;
                k->pnext = NULL;
                l.ptail = k;
            }
        }
    }
}
void removeA(listA& l, int x) {
    nodeA* q = new nodeA;
    q->soghetrong = x;
    if (l.phead == NULL) {
        cout << "khong co du lieu de xoa\n";
    }
    else {
        if (l.phead->soghetrong == x) {
            removeA_before(l, x);
            return ;
        }
        else if (l.ptail->soghetrong == x) {
            removeA_after(l, x);
            return ;
        }
        else {
            nodeA* f = new nodeA;
            for (nodeA* k = l.phead; k != NULL; k = k->pnext) {
                if (x == k->soghetrong) {
                    f->pnext = k->pnext;

                    delete k;
                    return ;//xóa node nằm sau node q
                }
                f = k;//cho node g trỏ đến node k
            }
        }

        }
    }
//thêm vào đầu
void themvaodau(listA& l, int x) {
    nodeA* data = new nodeA;
    data->soghetrong = x;
    data->pnext = NULL;
    if (l.phead == NULL) {
        data->pnext = l.phead;
        l.phead = data;
    }
    
}
//them vào vị trí bất kì
void themvaobk(listA& l, int x) {
    nodeA* data = new nodeA;
    
    if (l.phead == NULL) {
        themvaodau(l, x);
    }
    else {
        themvaocuoiA(l, x);
    }
    cout << "da them vao A";
}
//show list A
void showA(listA l) {
    for (nodeA* k = l.phead; k != NULL; k=k->pnext) {
        cout << k->soghetrong << ";";
    }
}


typedef queue<int> listB;
void laysothutu(listB& B) {
    
    if (B.empty() == true) {
        B.push(1);
    }
    else {
        B.push(B.back()+1);
    }
    
}

//khai báo một nodec
struct nodeC {
    int soghe;
    string name;
    nodeC* pnext;

};
struct listC
{
    nodeC * phead;
    nodeC* ptail;
};
//khởi tạo nodeC
void taolistC(listC &l){
    l.phead = l.ptail = NULL;
}
void putC(listC& a, int soghe, string name)
{
    nodeC* c = new nodeC[1];
    (c->name, name);
    c->soghe = soghe;
    c->pnext = NULL;
    if (a.phead == NULL)
        a.phead = a.ptail = c;
    else
    {
        a.ptail->pnext = c;
        a.ptail = c;
    }
}
//xóa

//xóa c
void removeC_before(listC& l, int x) {
    nodeC* q = new nodeC;
    q->soghe = x;
    if (l.phead == NULL) {
        cout << "khon co du lieu de xoa";
    }
    else {
        nodeC* p = l.phead;
        l.phead = l.phead->pnext;//cập nhật lại l.phead là phần tử kế tiếp
        delete p;
    }
}
void removeC_after(listC& l, int x) {
    nodeC* q = new nodeC;
    q->soghe = x;
    if (l.phead == NULL) {
        cout << "khong co du lieu de xoa!!\n";
    }
    else {
        for (nodeC* k = l.phead; k != NULL; k->pnext) {
            if (k->pnext = l.ptail) {
                delete l.ptail;
                k->pnext = NULL;
                l.ptail = k;
            }
        }
    }
}
void removeC(listC& l, int x) {
    nodeC* q = new nodeC;
    q->soghe = x;
    if (l.phead == NULL) {
        cout << "khong co du lieu de xoa\n";
    }
    else {
        if (l.phead->soghe == x) {
            removeC_before(l, x);
            return;
        }
        else if (l.ptail->soghe == x) {
            removeC_after(l, x);
            return;
        }
        else {
            nodeC* f = new nodeC;
            for (nodeC* k = l.phead; k != NULL; k = k->pnext) {
                if (x == k->soghe) {
                    f->pnext = k->pnext;

                    delete k;
                    return;//xóa node nằm sau node q
                }
                f = k;//cho node g trỏ đến node k
            }
        }

    }
}
//show C
void showC(listC l) {
    for (nodeC* k = l.phead; k != NULL; k = k->pnext) {
        cout << "name" << k->name<<endl;
        cout << "so ghe" << k->soghe << endl;
    }
}
//mua vé
void muave(listA& A, listB& B, listC& C,int n) {
    string name;
    int soghe;
    //int so;
   
    
    if (A.phead != NULL) {
        if (B.empty() == false) {
            showA(A);
            cout << "ten khach hang: ";
            cin >> name;
            do {

                cout << "so ghe:";
                cin >> soghe;
                if (position(A, soghe) == -1) {
                    cout << "ko co gh trong rap\n";
                }


            } while (position(A, soghe) == -1);
            removeA(A, soghe);
            putC(C, soghe, name);
            B.pop();
        }
        else {
            cout << "ko con cho\n";
        }
    }
    else {
        cout << "hay xep hang\n";
     
    }

}
//chức năng hủy vé
void huyve(listA& A, listB& B, listC& C, int n) {
    int soghe;
    string name;
    if (A.phead == NULL) {
        cout << "ko co du lieu de xoa\n";
    }
    else {
        cout << "nhap so ghe: "; cin >> soghe;
       
        
       
        themvaocuoiA(A, soghe);
    }
}
void menu(listA A,listB B,listC C,int n) {
    int check;
lap:
    cout << "\t\t\n===================show_Menu====================\n";
    cout << " -------------------------------------------------------------" << endl;
    cout << " | Lua chon cac chuc nang. |" << endl;
    cout << " | Bam so 1 :lay so xep hang. |" << endl;
    cout << " | Bam so 2 :de chon chuc nang mua ve. |" << endl;
    cout << " | Bam so 3 :de chon chuc nang huy ve. |" << endl;
    cout << " | bam so 4 :de hien thi thong tin. |" << endl;
    cout << " | Bam so 0 :neu ban muon thoat khoi chuong trinh. |" << endl;
    cout << "\t\t\n=====================END==========================\n";
    cout << "bam lua chon:";
    cin >> check;
    switch (check)
    {
    case 0:return ;
    case 1:laysothutu(B);

        goto lap;
    case 2: muave(A, B, C,n);
        goto lap;
    case 3: huyve(A, B, C, n);
        goto lap;
    case 4:showC(C);
        
        goto lap;
    default:cout << "Xin moi ban lua chon lai: ";
        goto lap;
    }
}
int main()
{
    listA A;
    listB B;
    listC C;
    int n;

    A.phead = A.ptail = NULL;
    
    C.phead = C.ptail = NULL;
    cout << "nhap vao so ghe cua trong rap";
    cin >> n;
    for (int i = 1; i < n; i++) {
        themvaocuoiA(A, i);
    }
    
    menu(A, B, C,n);
    
    
}

